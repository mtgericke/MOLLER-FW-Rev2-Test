// CRC32 simulation using LFSR
// Mostly to help understanding how it works and compare with online calculators

// input is not reflected nor inverted
// LFSR initialization is 0
// output is not reflected nor inverted


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.zip.CRC32;

public class main {
	
	public static void main(String[] args) {
		byte[] message = new byte[]{(byte)0xff};
		int crc,crcxor = 0;
		int databyte = 0x00;
		int i,j = 0;
		int nbytes = message.length;
		

		
		crc = 0x6b6dc92a;	// initialization
		
		for(j = 0; j <nbytes; j++){
			databyte = (int)message[j];
			for(i = 0; i<8; i++){
				if(((crc & 0x80000000) == 0x80000000) && ((databyte & 0x0080) == 0x0080)) {
					crcxor = 0;
				} else if(((crc & 0x80000000) == 0) && ((databyte & 0x0080) == 0)) {
					crcxor = 0;
				} else {
					crcxor = 0x04C11DB7;
				}
			
				crc <<= 1;
				crc ^= crcxor;
				databyte <<= 1;
			}
		}
		System.out.println("done");
		
	}
}
